/*
	1. Запросите у пользователя его имя и выведите в ответ:
	«Привет, его имя!».
*/

var Name = prompt("What`s your name?");
alert(`Hey, ${Name}!`);