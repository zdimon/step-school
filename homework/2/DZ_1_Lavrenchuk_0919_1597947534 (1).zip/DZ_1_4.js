/*
	4. Запросите у пользователя радиус окружности и выведите
	площадь такой окружности.
*/

var r = prompt("Enter circle radius");
alert(`Area: ${ Math.PI * r**2 }`);