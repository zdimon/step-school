/*
	2. Запросите у пользователя год его рождения, посчитайте,
	сколько ему лет и выведите результат. Текущий год укажите
	в коде как константу.
*/

const CurrentYear = 2020;
var YearOfBirth = prompt("Enter your year of birth");
alert(`You ${ CurrentYear - YearOfBirth } years old`);