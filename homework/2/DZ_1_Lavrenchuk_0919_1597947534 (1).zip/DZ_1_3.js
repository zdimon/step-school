/*
	3. Запросите у пользователя длину стороны квадрата и выведите периметр такого квадрата.
*/

var SideLength = prompt("Enter side length of square");
alert(`Area: ${ SideLength**2 }`);